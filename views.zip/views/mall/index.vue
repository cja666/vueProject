<template>
    <div>
        <h1>这是商品管理页面成功的开始</h1>
    </div>
</template>
<script>
export default {
    name:'mall',
    data(){
        return{}
    }
}
</script>