<template>
    <div>
        <h1>第二个页面</h1>
    </div>
</template>
<script>
export default {
    name:'PageTwe',
    data(){
        return{}
    }
}
</script>