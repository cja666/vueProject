<template>
    <div>
        <h1>第一个页面</h1>
    </div>
</template>
<script>
export default {
    name:'PageOne',
    data(){
        return{}
    }
}
</script>