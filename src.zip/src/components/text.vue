 <template>
    <el-table
      :data="tableData"
      style="width: 100%">
      <el-table-column
        prop="birth"
        label="出生日期"
        width="180">
      </el-table-column>
      <el-table-column
        prop="name"
        label="姓名"
        width="180">
      </el-table-column>
        <el-table-column
        prop="age"
        label="年龄"
        width="180">
      </el-table-column>
        <el-table-column
        prop="sexLabel"
        label="性别"
        width="180">
      </el-table-column>
      <el-table-column
        prop="addr"
        label="地址">
      </el-table-column>
       <el-table-column label="操作" min-width="180">
            <template slot-scope="scope">
               <el-button size="mini" @click="handleEdit(scope.row)">编辑</el-button>
               <el-button size="mini" type="danger" @click="handleDelete(scope.row)">删除</el-button>
            </template>          
        </el-table-column>
    </el-table>
      
    
  </template>

  <script>
    export default {
      name:'CommonTable',
      data() {
        return {
          tableData: [{
            birth: '2016-05-02',
            name: '王小虎',
            age:52,
            sexLabel:'女',
            addr: '上海市普陀区金沙江路 1518 弄'
          }, {
            birth: '2016-05-02',
            name: '王小虎',
            age:52,
            sexLabel:'男',
            addr: '上海市普陀区金沙江路 1518 弄'
          }, {
            birth: '2016-05-02',
            name: '王小虎',
            age:52,
            sexLabel:'女',
            addr: '上海市普陀区金沙江路 1518 弄'
          }, {
            birth: '2016-05-02',
            name: '王小虎',
            age:52,
            sexLabel:'女',
            addr: '上海市普陀区金沙江路 1518 弄'
          },
          ]
        }
      },
          methods: {
        handleEdit(row){
            this.$emit('edit',row)
        },
        handleDelete(row){
            this.$emit('del',row)
        },
        changePage(page){
            this.$emit('changePage',page)

        }
    },
    }
  </script>