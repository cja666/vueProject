export default{
    baseUrl:'/api/',
    pro:''
}